import React, { useState, useEffect } from 'react'

const UserHome = () => {
    const [task, setTask] = useState([]);
    const [show, setShow] = useState(0)


    useEffect(() => {
        const fetchTask = async () => {
            let resp = await fetch("http://localhost:5000/Task");
            let data = await resp.json();
            console.log(data)
            setTask(data)
        };
        fetchTask();

    }, [show]);


    console.log(task)


    return (
        <div>
            <h1>User home</h1>
            {
        // Object.entries(task).map( value=>{
        //     Object.entries(value).map(obj=>{
        //         return (
        //             <>
        //             <div style={{height:"30vh", width:"20vh", backgroundColor:"red"}}>
        //                     {obj[0].map((value=>{
        //                       console.log(value)
        //                     }))}
        //             </div>
        //             </>
        //         )
        //     })
        // })

        // task.data.map((val)=>{
        //     return (
        //         <>
        //           <h1>{val}</h1>
        //         </>
        //     )
        // })
        
      }


            <div style={{ display: "flex", flexDirection: "row" }}>
                {
                    // task.map((value) => {
                    //     return (<>
                    //         <div style={{ height: "30vh", width: "30vh", backgroundColor: 'red' }}>
                    //              <h1>value.id</h1>
                    //             <h3>value.taskIdem</h3>                                
                    //         </div>
                    //     </>)
                    // })
                }
            </div>

        </div>
    )
}

export default UserHome
