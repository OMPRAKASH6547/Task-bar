import React, { useEffect, useState,Draggable } from 'react'
import UserHome from './UserHome';


const Login = () => {
    const [username,setUsername]=useState("");
    const [password,setPassword]=useState("");
    const [userData,setUserdata]=useState([]);
    const [show, setShow] = useState(0);
    const [displayHome,setDisplayHome]=useState(true)


    useEffect(() => {
        const fetchNotes = async () => {
          let resp = await fetch("http://localhost:5000/users");
          let data = await resp.json();
          console.log(data)
          setUserdata(data);
        };
        fetchNotes();
       
      }, [show]);

    

   const handleLogin=(e)=>{
    e.preventDefault();


    
    setDisplayHome(
      userData.reduce((value)=>{
        
        if(value.username===username && value.password===password){
          return false
        }

        else{
          return true
        }
      },true))

   }
  return (
    <>
    {
   displayHome? <div className="form"  >
     <form onSubmit={handleLogin}>
       <div className="input-container">
         <label>Username </label>
         <input type="text" name="uname" required onChange={(e)=>{
             setUsername(e.target.value)
         }}/>
         
       </div>
       <div className="input-container">
         <label>Password </label>
         <input type="password" name="pass" required  onChange={e=>{
          setPassword(e.target.value)
         }}/>

       </div>
       <div className="button-container">
         <input type="submit" />
       </div>
     </form>
   </div>
:
   <UserHome/>
   
        }
    </>
        
  )
}

export default Login
