import './App.css';
import Login from './Login';

function App() {
  return (<>
      <header style={{display:'flex', backgroundColor:'blue'}}>
        <div>
          <h1>Welcome</h1>
        </div>

      </header>
    <Login/>
    </>
  );
}

export default App;
